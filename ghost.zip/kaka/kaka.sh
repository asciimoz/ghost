echo -e "$(<ghost0.txt)"
sleep 2
clear
echo -e "$(<ghost.txt)"
sleep 2
while true;
do
sleep 1
clear
echo -e "$(<ghost1.txt)"
sleep 1
clear
echo -e "$(<ghost2.txt)"
sleep 1
clear
echo -e "$(<ghost3.txt)"
sleep 1
clear
echo -e "$(<ghost4.txt)"
sleep 1
clear
echo -e "$(<ghost5.txt)"
sleep 1
clear
echo -e "$(<ghost6.txt)"
sleep 1
clear
echo -e "$(<ghost7.txt)"
sleep 1
clear
echo -e "$(<ghost8.txt)"
sleep 1
clear
echo -e "$(<ghost9.txt)"
sleep 1
clear
echo -e "$(<ghost10.txt)"
sleep 1
clear
echo -e "$(<ghost11.txt)"
sleep 1
clear
echo -e "$(<ghost12.txt)"
sleep 1
clear
echo -e "$(<ghost13.txt)"
sleep 1
clear
echo -e "$(<ghost14.txt)"
sleep 1
clear
echo -e "$(<ghost15.txt)"
sleep 1
clear
echo -e "$(<ghost16.txt)"
sleep 1
clear
echo -e "$(<ghost17.txt)"
sleep 1
clear
echo -e "$(<ghost18.txt)"
sleep 1
clear
echo -e "$(<ghost19.txt)"
sleep 1
clear
echo -e "$(<ghost20.txt)"
sleep 1
clear
echo -e "$(<ghost21.txt)"
sleep 1
clear
echo -e "$(<ghost22.txt)"
sleep 1
clear
echo -e "$(<ghost23.txt)"
sleep 1
clear
echo -e "$(<ghost24.txt)"
sleep 1
clear
echo -e "$(<ghost25.txt)"
sleep 1
clear
echo -e "$(<ghost26.txt)"
sleep 1
clear
echo -e "$(<ghost27.txt)"
sleep 1
clear
echo -e "$(<ghost28.txt)"
sleep 1
clear
echo -e "$(<ghost29.txt)"
sleep 1
clear
echo -e "$(<ghost30.txt)"
sleep 1
clear
echo -e "$(<ghost31.txt)"
sleep 1
clear
echo -e "$(<ghost32.txt)"
sleep 1
clear
echo -e "$(<ghost33.txt)"
sleep 1
clear
echo -e "$(<ghost34.txt)"
sleep 1
clear
echo -e "$(<ghost35.txt)"
sleep 1
clear
echo -e "$(<ghost36.txt)"
sleep 1
clear
echo -e "$(<ghost37.txt)"
sleep 1
clear
echo -e "$(<ghost38.txt)"
sleep 1
clear
echo -e "$(<ghost39.txt)"
sleep 1
clear
echo -e "$(<ghost40.txt)"
sleep 1
clear
echo -e "$(<ghost41.txt)"
sleep 1
clear
echo -e "$(<ghost42.txt)"
sleep 1
clear
echo -e "$(<ghost43.txt)"
sleep 1
clear
echo -e "$(<ghost44.txt)"
sleep 1
clear
echo -e "$(<ghost45.txt)"
sleep 1
clear
echo -e "$(<ghost46.txt)"
sleep 1
clear
echo -e "$(<ghost47.txt)"
sleep 1
clear
echo -e "$(<ghost48.txt)"
sleep 2
done
